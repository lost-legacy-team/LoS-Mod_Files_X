DebugLog_Enabled = false
Multiplayer4P_Enabled = false -- (requires custom files)
NoArcMode = false -- (requires custom patch for xex also other version of game)
TimeSystemRestore = false
OmegaHoverGauge = true