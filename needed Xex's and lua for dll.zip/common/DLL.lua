OmegaHoverGauge = true
TailsGauge = true