OmegaHoverGauge = true
TailsGauge = true
AmyLOS = false


