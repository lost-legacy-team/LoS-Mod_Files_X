OmegaHoverGauge = true
TailsGauge = false


